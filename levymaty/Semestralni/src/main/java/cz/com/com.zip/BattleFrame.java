/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.com.Testing;

import cz.com.LevyatonRPGEngine.LevyBuild.Methods.Main;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintStream;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 *
 * @author czech
 */
public class BattleFrame extends JFrame
{
    
    
    
    
    int mod = 50;
    
    Main m = new Main();
    ActionListener al = m;
    
    public JButton con;
    public JButton newGame;
    
    boolean pressed = false;
    
    JScrollPane scroller = new JScrollPane();
    
    public JTextArea textOut;
    
    JTextArea textIn;
    
    JPanel basePanel;
    
    
    JPanel animationPanel;
    
    JPanel buttonPanel;
    
    JPanel selectedPanel;
    
    JTextAreaOutputStream out;
    
    static GraphicsConfiguration gc;

    String newGameOrContinue;
    
    
    public BattleFrame() throws InterruptedException
    {
        super("Battle Window");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(24*mod,20*mod);    
        setLayout(null);    
        setBackground(Color.yellow);
        baseFrame();
        setVisible(true);
        System.out.println("Welcome, warrior! Would you like to continue your adventure, or shall you start fresh?\n");
    }   
        
      
    
    
   
    
    
    public void makeBase()
    {
        this.removeAll();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(24*mod,20*mod);    
        setLayout(null);    
        setBackground(Color.yellow);
        
        baseFrame();
        
        setVisible(true);  
    }
   
    
    private void baseFrame()
    {
     this.baseTextOut();
     this.basePanel();
     this.add(basePanel);
     this.add(textOut);
    }
    
    private void baseTextOut()
    {
        textOut = new JTextArea();
        textOut.setForeground(Color.RED);
        textOut.setBackground(Color.BLACK);
        textOut.setFont(new Font("Serif", Font.ITALIC, 16));
        textOut.setLineWrap(true);
        textOut.setWrapStyleWord(true);
        textOut.setEditable (false);
        textOut.setBounds(0,0,24*mod,18*mod);
        textOut.setVisible(true);
        out = new JTextAreaOutputStream(textOut);
        System.setOut (new PrintStream (out));  
    }
    
   
   

    
    private void basePanel()
    {
        basePanel = new JPanel();
        basePanel.setBounds(0,18*mod,24*mod,4*mod);   
        basePanel.setBackground(Color.GRAY);
        newGame = new JButton("New Game"); 
        newGame.setForeground(Color.RED);
        newGame.addActionListener(al);
        con = new JButton("Continue");
        con.setName("continue");
        con.setForeground(Color.RED);
        newGame.addActionListener(al);
        basePanel.add(con);
        basePanel.add(newGame);
        
    }
    
    
   
    
    public String getNewGameOrContinue()
    {
        return newGameOrContinue;
    }
    
    public void makeBattleFrame()
    {
        setter();
        this.add(textOut);
        this.add(animationPanel);
        this.add(buttonPanel);
        this.add(selectedPanel);
        
        
    }
    
    private void setter()
    {
        animationPanel();
        textOutput();
        buttonPanel();
        selectedPanel();
        
    }
    
    private void animationPanel()
    {
        animationPanel = new JPanel();  
        animationPanel.setBounds(0,0,16*mod,14*mod);    
        animationPanel.setBackground(Color.GRAY);  
    }
    
   
     
    public void textOutput()
    {
       
        textOut = new JTextArea();
        textOut.setForeground(Color.RED);
        textOut.setBackground(Color.BLACK);
        textOut.setFont(new Font("Serif", Font.ITALIC, 16));
        textOut.setLineWrap(true);
        textOut.setWrapStyleWord(true);
        textOut.setEditable (true);
        textOut.setBounds(0,14*mod,16*mod,4*mod);
        textOut.add(scroller);
        textOut.setVisible(true);
        out = new JTextAreaOutputStream(textOut);
        System.setOut (new PrintStream (out));
    }
    
    public void textOutput(String givenText)
    {
       
        textOut = new JTextArea(givenText);
        textOut.setForeground(Color.RED);
        textOut.setBackground(Color.BLACK);
        textOut.setFont(new Font("Serif", Font.ITALIC, 16));
        textOut.setLineWrap(true);
        textOut.setWrapStyleWord(true);
        textOut.setBounds(0,14*mod,16*mod,4*mod); 
        textOut.add(scroller);
        textOut.setVisible(true);
    }
    
  /*
    private JPanel textOutput (JPanel panel, String s)
    {
        char[] chars = s.toCharArray();
        String currentS = "";
        
        for(char c : chars)   
        {
            currentS += c;
            panel.add(textOutputPanel(currentS));
            revalidate();
            repaint();
        }
        return panel;
    }
 */
    
    private void buttonPanel()
    {
        buttonPanel=new JPanel();  
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));

        buttonPanel.setBounds(0,18*mod,16*mod,4*mod);    
        buttonPanel.setBackground(Color.CYAN);  
        
        JButton attack = new JButton("Attack");     
        attack.setBackground(Color.RED);  
       
        

        JButton bag = new JButton("Bag");     
        bag.setBackground(Color.RED);
        
        JButton run = new JButton("Run");     
        run.setBackground(Color.RED);
        
        JButton log = new JButton("Battle log");     
        log.setBackground(Color.RED);
        
        buttonPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonPanel.add(attack);
        buttonPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonPanel.add(bag);
        buttonPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonPanel.add(run);
        buttonPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonPanel.add(log);

      
    }
    
     private void selectedPanel()
    {
        selectedPanel=new JPanel();  
        selectedPanel.setBounds(16*mod,0,8*mod,20*mod);    
        selectedPanel.setBackground(Color.YELLOW);  
    }

}
